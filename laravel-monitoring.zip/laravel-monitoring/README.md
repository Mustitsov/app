# Travellist - Laravel Demo App

This is a Laravel demo application.

Relevant Tutorials:

- [How to Install and Configure Laravel with LEMP on Ubuntu 18.04](https://www.digitalocean.com/community/tutorials/how-to-install-and-configure-laravel-with-lemp-on-ubuntu-18-04)


